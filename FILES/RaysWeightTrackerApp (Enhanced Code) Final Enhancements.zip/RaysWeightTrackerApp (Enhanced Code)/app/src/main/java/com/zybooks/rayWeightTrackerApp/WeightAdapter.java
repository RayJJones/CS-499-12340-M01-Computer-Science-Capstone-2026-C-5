package com.zybooks.rayWeightTrackerApp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.rayWeightTrackerApp.model.WorkoutHistory;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * RecyclerView adapter that displays weight-history records.
 *
 * Each card displays:
 * - Date
 * - Weight
 * - Daily steps
 * - Edit button
 * - Delete button
 */
public class WeightAdapter
        extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final Context context;
    private List<WorkoutHistory> historyList;

    private final OnDeleteClickListener deleteListener;
    private final OnEditClickListener editListener;

    /**
     * Callback used when the user selects Delete.
     */
    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    /**
     * Callback used when the user selects Edit.
     */
    public interface OnEditClickListener {
        void onEditClick(int position);
    }

    /**
     * Creates the weight-history adapter.
     */
    public WeightAdapter(
            Context context,
            ArrayList<WorkoutHistory> historyList,
            OnDeleteClickListener deleteListener,
            OnEditClickListener editListener
    ) {
        this.context = context;
        this.historyList = historyList;
        this.deleteListener = deleteListener;
        this.editListener = editListener;
    }

    /**
     * Optionally filters the displayed entries by weight range.
     */
    public void filterByWeightRange(
            float minimumWeight,
            float maximumWeight
    ) {
        List<WorkoutHistory> filteredList =
                new ArrayList<>();

        for (WorkoutHistory history : historyList) {
            if (history.getWeight() >= minimumWeight
                    && history.getWeight() <= maximumWeight) {

                filteredList.add(history);
            }
        }

        historyList = filteredList;
        notifyDataSetChanged();
    }

    /**
     * Creates each weight-history card.
     */
    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        View view =
                LayoutInflater
                        .from(context)
                        .inflate(
                                R.layout.row_weight,
                                parent,
                                false
                        );

        return new WeightViewHolder(view);
    }

    /**
     * Places the history data into a card.
     */
    @Override
    public void onBindViewHolder(
            @NonNull WeightViewHolder holder,
            int position
    ) {
        WorkoutHistory entry =
                historyList.get(position);

        holder.tvDate.setText(
                entry.getDate()
        );

        holder.tvWeight.setText(
                context.getString(
                        R.string.weight_format,
                        entry.getWeight()
                )
        );

        /*
         * Formats large step counts with commas.
         *
         * Example:
         * 10500 becomes 10,500.
         */
        String formattedSteps =
                NumberFormat
                        .getIntegerInstance(Locale.US)
                        .format(entry.getSteps());

        holder.tvSteps.setText(
                context.getString(
                        R.string.steps_format_text,
                        formattedSteps
                )
        );

        /*
         * Use getBindingAdapterPosition instead of the original
         * position because positions can change after deleting
         * or filtering a RecyclerView item.
         */
        holder.btnDelete.setOnClickListener(view -> {
            int adapterPosition =
                    holder.getBindingAdapterPosition();

            if (adapterPosition
                    != RecyclerView.NO_POSITION) {

                deleteListener.onDeleteClick(
                        adapterPosition
                );
            }
        });

        holder.btnEdit.setOnClickListener(view -> {
            int adapterPosition =
                    holder.getBindingAdapterPosition();

            if (adapterPosition
                    != RecyclerView.NO_POSITION) {

                editListener.onEditClick(
                        adapterPosition
                );
            }
        });
    }

    /**
     * Returns the number of history entries displayed.
     */
    @Override
    public int getItemCount() {
        return historyList.size();
    }

    /**
     * Holds the views contained in one history card.
     */
    public static class WeightViewHolder
            extends RecyclerView.ViewHolder {

        private final TextView tvDate;
        private final TextView tvWeight;
        private final TextView tvSteps;

        private final Button btnDelete;
        private final Button btnEdit;

        public WeightViewHolder(
                @NonNull View itemView
        ) {
            super(itemView);

            tvDate =
                    itemView.findViewById(
                            R.id.tvDate
                    );

            tvWeight =
                    itemView.findViewById(
                            R.id.tvWeight
                    );

            tvSteps =
                    itemView.findViewById(
                            R.id.tvSteps
                    );

            btnDelete =
                    itemView.findViewById(
                            R.id.btnDelete
                    );

            btnEdit =
                    itemView.findViewById(
                            R.id.btnEdit
                    );
        }
    }
}