package com.zybooks.rayWeightTrackerApp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class GoalDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "goal.db";
    private static final int VERSION = 1;

    private static final String TABLE_GOAL = "goal";
    private static final String COL_ID = "_id";
    private static final String COL_GOAL_WEIGHT = "goal_weight";

    public GoalDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_GOAL + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_GOAL_WEIGHT + " REAL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        onCreate(db);
    }

    public boolean setGoalWeight(double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_GOAL, null, null); // only one goal allowed

        ContentValues values = new ContentValues();
        values.put(COL_GOAL_WEIGHT, goalWeight);

        long result = db.insert(TABLE_GOAL, null, values);
        return result != -1;
    }

    public double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COL_GOAL_WEIGHT + " FROM " + TABLE_GOAL, null);

        if (cursor.moveToFirst()) {
            double goal = cursor.getDouble(0);
            cursor.close();
            return goal;
        }

        cursor.close();
        return 0;
    }
}


