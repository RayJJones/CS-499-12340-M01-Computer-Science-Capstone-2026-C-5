package com.zybooks.rayWeightTrackerApp.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zybooks.rayWeightTrackerApp.model.User;
import com.zybooks.rayWeightTrackerApp.security.PasswordUtils;

public class UserDao {

    private final AppDatabaseHelper dbHelper;

    public UserDao(Context context) {
        this.dbHelper = new AppDatabaseHelper(context);
    }

    public long insertUser(String name, String email, String plainPassword) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("email", email);
        values.put("password_hash", PasswordUtils.hashPassword(plainPassword));
        return db.insert("Users", null, values);
    }

    public User getUserByEmail(String email) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT id, name, email, password_hash FROM Users WHERE email = ?",
                new String[]{email}
        );

        if (cursor.moveToFirst()) {
            long id = cursor.getLong(0);
            String name = cursor.getString(1);
            String em = cursor.getString(2);
            String hash = cursor.getString(3);
            cursor.close();
            return new User(id, name, em, hash);
        }
        cursor.close();
        return null;
    }
}
