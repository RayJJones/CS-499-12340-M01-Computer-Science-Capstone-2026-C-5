package com.zybooks.rayWeightTrackerApp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

/**
 * updating username and password.
 * - Stronger validation
 * - Defensive coding
 * - Clearer user feedback
 * - Improved structure and comments
 */
public class SettingsActivity extends AppCompatActivity {

    private EditText etNewUsername;
    private EditText etNewPassword;

    private UserDatabaseHelper userDb;
    private String currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize UI components
        etNewUsername = findViewById(R.id.etNewUsername);
        etNewPassword = findViewById(R.id.etNewPassword);

        // Convert to local variable (removes warning)
        Button btnSaveSettings = findViewById(R.id.btnSaveSettings);

        // Initialize database helper
        userDb = new UserDatabaseHelper(this);

        // Retrieve logged-in username
        currentUser = getIntent().getStringExtra("username");

        // Navigate back to dashboard
        Button btnBackHome = findViewById(R.id.btnBackHome);
        btnBackHome.setOnClickListener(v ->
                startActivity(new Intent(this, DashboardActivity.class)));

        // Save updated settings
        btnSaveSettings.setOnClickListener(v -> saveSettings());
    }

    /**
     * Validates and updates user account information.
     * Enhanced with:
     * - Input sanitization
     * - Password strength rules
     * - Defensive null checks
     * - Clear error messages
     */
    private void saveSettings() {
        String newUsername = etNewUsername.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();

        // Enhanced: Defensive check to ensure logged-in user exists
        if (currentUser == null || currentUser.isEmpty()) {
            Toast.makeText(this, "Error: No user logged in.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate username
        if (newUsername.isEmpty()) {
            etNewUsername.setError("Please enter a username");
            return;
        }

        if (newUsername.length() < 3) {
            etNewUsername.setError("Username must be at least 3 characters");
            return;
        }

        // Validate password
        if (newPassword.isEmpty()) {
            etNewPassword.setError("Please enter a password");
            return;
        }

        // Enhanced: Stronger username and password validation rules
        if (newPassword.length() < 6) {
            etNewPassword.setError("Password must be at least 6 characters");
            return;
        }

        // Optional: Add simple password strength check
        if (!newPassword.matches(".*[A-Za-z].*") || !newPassword.matches(".*\\d.*")) {
            etNewPassword.setError("Password must contain letters and numbers");
            return;
        }

        // TODO: Add hashing before saving password (Milestone 3 - Enhancement)

        boolean success = userDb.updateUser(currentUser, newUsername, newPassword);

        if (success) {
            Toast.makeText(this, "Settings updated!", Toast.LENGTH_SHORT).show();
            finish(); // Return to Dashboard
        } else {
            Toast.makeText(this, "Error updating settings", Toast.LENGTH_SHORT).show();
        }
    }
}
