package com.zybooks.rayWeightTrackerApp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.rayWeightTrackerApp.data.AppDatabaseHelper;

/**
 * Login screen for the Weight Tracker application.
 *
 * Account creation takes place on CreateAccountActivity.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;

    private AppDatabaseHelper appDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        appDb = new AppDatabaseHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreate);

        btnLogin.setOnClickListener(v -> handleLogin());

        btnCreate.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                MainActivity.this,
                                CreateAccountActivity.class
                        )
                )
        );
    }

    /**
     * Validates credentials and starts the dashboard.
     */
    private void handleLogin() {
        String username =
                etUsername.getText().toString().trim();

        String password =
                etPassword.getText().toString();

        if (username.isEmpty()) {
            etUsername.setError(
                    getString(R.string.error_username_required)
            );

            etUsername.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            etPassword.setError(
                    getString(R.string.error_password_required)
            );

            etPassword.requestFocus();
            return;
        }

        long userId = appDb.validateLogin(
                username,
                password
        );

        if (userId == -1) {
            Toast.makeText(
                    this,
                    R.string.invalid_login,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        SharedPreferences session =
                getSharedPreferences(
                        "userSession",
                        MODE_PRIVATE
                );

        session.edit()
                .putLong("userId", userId)
                .putString("username", username)
                .apply();

        Toast.makeText(
                this,
                R.string.login_successful,
                Toast.LENGTH_SHORT
        ).show();

        startActivity(
                new Intent(
                        MainActivity.this,
                        DashboardActivity.class
                )
        );

        finish();
    }
}