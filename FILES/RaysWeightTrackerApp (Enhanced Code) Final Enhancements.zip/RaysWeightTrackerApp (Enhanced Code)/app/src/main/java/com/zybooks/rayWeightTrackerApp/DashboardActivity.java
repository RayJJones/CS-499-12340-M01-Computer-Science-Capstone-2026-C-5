package com.zybooks.rayWeightTrackerApp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.rayWeightTrackerApp.data.AppDatabaseHelper;

import java.util.Locale;

/**
 * Main dashboard showing weight progress and goal-based recommendations.
 *
 * Dashboard feedback:
 * - First weight entry: no message
 * - Moving toward goal: progress message
 * - Moving away from goal: setback message
 * - Same weight: keep-going message
 * - Goal reached: celebration message
 */
public class DashboardActivity extends AppCompatActivity {

    /**
     * Used to compare decimal weight values safely.
     */
    private static final double WEIGHT_COMPARISON_TOLERANCE = 0.01;

    /**
     * A maintain-weight goal is considered reached when the
     * latest weight is within two pounds of the goal.
     */
    private static final double MAINTAIN_WEIGHT_RANGE = 2.0;

    private ProgressBar progressGoal;
    private TextView tvGoalStatus;
    private TextView tvCongrats;
    private TextView tvRecommendations;

    private TextView tvWelcomeUser;

    private AppDatabaseHelper appDb;
    private long userId;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        tvWelcomeUser =
                findViewById(
                        R.id.tvWelcomeUser
                );
        // Initialize dashboard views.
        progressGoal = findViewById(R.id.progressGoal);
        tvGoalStatus = findViewById(R.id.tvGoalStatus);
        tvCongrats = findViewById(R.id.tvCongrats);
        tvRecommendations = findViewById(R.id.tvRecommendations);

        Button btnAddNewWeight =
                findViewById(R.id.btnAddNewWeight);

        Button btnSetGoal =
                findViewById(R.id.btnSetGoal);

        Button btnViewHistory =
                findViewById(R.id.btnViewHistory);

        Button btnSettings =
                findViewById(R.id.btnSettings);

        // Initialize the unified database.
        appDb = new AppDatabaseHelper(this);

        // Retrieve the signed-in user's ID.
        SharedPreferences session =
                getSharedPreferences(
                        "userSession",
                        MODE_PRIVATE
                );

        userId = session.getLong(
                "userId",
                1L
        );

        String username =
                appDb.getUsername(userId);

        tvWelcomeUser.setText(
                "Hello " + username + "!"
        );
        // Open Add Weight screen.
        btnAddNewWeight.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                DashboardActivity.this,
                                AddWeightActivity.class
                        )
                )
        );

        // Open Goal Weight screen.
        btnSetGoal.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                DashboardActivity.this,
                                GoalWeightActivity.class
                        )
                )
        );

        // Open Weight History screen.
        btnViewHistory.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                DashboardActivity.this,
                                WeightHistoryActivity.class
                        )
                )
        );

        // Open Settings screen.
        btnSettings.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                DashboardActivity.this,
                                SettingsActivity.class
                        )
                )
        );
    }

    /**
     * Refreshes dashboard information whenever the user returns
     * after adding a weight, editing a weight, or changing a goal.
     */
    @Override
    protected void onResume() {
        super.onResume();

        updateProgress();
        updateRecommendations();
    }

    /**
     * Updates the progress bar, latest-weight information,
     * and motivational feedback message.
     */
    private void updateProgress() {

        double goal =
                appDb.getGoalWeight(userId);

        double latest =
                appDb.getLatestWorkoutWeight(userId);

        // A goal and at least one weight are required.
        if (goal <= 0 || latest <= 0) {

            tvGoalStatus.setText(
                    R.string.no_goal_data
            );

            progressGoal.setProgress(0);

            tvCongrats.setText("");

            tvCongrats.setVisibility(
                    View.GONE
            );

            return;
        }

        SharedPreferences goalPreferences =
                getSharedPreferences(
                        "userGoals",
                        MODE_PRIVATE
                );

        String goalType =
                goalPreferences.getString(
                        "goalType",
                        ""
                );

        int progressValue =
                calculateProgressPercentage(
                        latest,
                        goal,
                        goalType
                );

        progressGoal.setProgress(
                progressValue
        );

        String statusText = String.format(
                Locale.getDefault(),
                getString(
                        R.string.goal_status_format
                ),
                latest,
                goal
        );

        tvGoalStatus.setText(
                statusText
        );

        double previous =
                appDb.getPreviousWorkoutWeight(userId);

        /*
         * There is no comparison after the first weight entry,
         * so no motivational message is shown.
         */
        if (previous <= 0) {

            tvCongrats.setText("");

            tvCongrats.setVisibility(
                    View.GONE
            );

            return;
        }

        /*
         * Reaching the selected goal takes priority over all
         * other progress messages.
         */
        if (hasReachedGoal(
                latest,
                goal,
                goalType
        )) {

            showGoalMessage(
                    R.string.goal_reached
            );

            return;
        }

        int weightComparison =
                compareWeights(
                        latest,
                        previous
                );

        /*
         * The newest and previous weights are the same.
         */
        if (weightComparison == 0) {

            showGoalMessage(
                    R.string.goal_same_weight
            );

            return;
        }

        boolean movingTowardGoal =
                isMovingTowardGoal(
                        weightComparison,
                        latest,
                        previous,
                        goal,
                        goalType
                );

        if (movingTowardGoal) {

            showGoalMessage(
                    R.string.goal_in_progress
            );

        } else {

            showGoalMessage(
                    R.string.goal_setback
            );
        }
    }

    /**
     * Compares the latest weight with the previous weight.
     *
     * @return -1 when the latest weight is lower,
     * 0 when the weights are equal, or
     * 1 when the latest weight is higher.
     */
    private int compareWeights(
            double latest,
            double previous
    ) {

        double difference =
                latest - previous;

        if (Math.abs(difference)
                <= WEIGHT_COMPARISON_TOLERANCE) {

            return 0;
        }

        if (difference > 0) {
            return 1;
        }

        return -1;
    }

    /**
     * Determines whether the selected goal has been reached.
     */
    private boolean hasReachedGoal(
            double latest,
            double goal,
            String goalType
    ) {

        // Lose-weight goal requires latest weight at or below goal.
        if (goalType.equals(
                getString(
                        R.string.goal_lose_weight
                )
        )) {

            return latest <= goal;
        }

        /*
         * Gain-weight, bulk-up, and lean-muscle goals require
         * the latest weight to be at or above the goal.
         */
        if (isGainGoal(goalType)) {

            return latest >= goal;
        }

        /*
         * Maintain-weight goal is reached when current weight
         * is within the allowed range of the goal.
         */
        if (goalType.equals(
                getString(
                        R.string.goal_maintain_weight
                )
        )) {

            return Math.abs(latest - goal)
                    <= MAINTAIN_WEIGHT_RANGE;
        }

        return false;
    }

    /**
     * Determines whether the latest weight moved in the correct
     * direction for the selected goal.
     */
    private boolean isMovingTowardGoal(
            int weightComparison,
            double latest,
            double previous,
            double goal,
            String goalType
    ) {

        /*
         * For a lose-weight goal, a lower latest weight means
         * the user moved toward the goal.
         */
        if (goalType.equals(
                getString(
                        R.string.goal_lose_weight
                )
        )) {

            return weightComparison < 0;
        }

        /*
         * For gain-oriented goals, a higher latest weight means
         * the user moved toward the goal.
         */
        if (isGainGoal(goalType)) {

            return weightComparison > 0;
        }

        /*
         * For a maintain goal, compare how far each weight is
         * from the target. The latest entry is progress when it
         * is closer to the goal than the previous entry.
         */
        if (goalType.equals(
                getString(
                        R.string.goal_maintain_weight
                )
        )) {

            double previousDistance =
                    Math.abs(previous - goal);

            double latestDistance =
                    Math.abs(latest - goal);

            return latestDistance
                    < previousDistance;
        }

        return false;
    }

    /**
     * Returns true for goals that require weight gain.
     */
    private boolean isGainGoal(String goalType) {

        return goalType.equals(
                getString(R.string.goal_gain_weight)
        ) || goalType.equals(
                getString(R.string.goal_bulk_up)
        ) || goalType.equals(
                getString(R.string.goal_gain_lean_muscle)
        );
    }

    /**
     * Displays a motivational message on the dashboard.
     */
    private void showGoalMessage(int messageResource) {

        tvCongrats.setText(messageResource);
        tvCongrats.setVisibility(View.VISIBLE);
    }

    /**
     * Calculates an estimated progress percentage based on
     * the user's selected goal type.
     *
     * This is an estimate because the app does not currently
     * store a separate starting weight for each new goal.
     */
    private int calculateProgressPercentage(
            double latest,
            double goal,
            String goalType
    ) {

        double percentage;

        if (isGainGoal(goalType)) {

            percentage = (latest / goal) * 100;

        } else if (goalType.equals(
                getString(R.string.goal_lose_weight)
        )) {

            percentage = (goal / latest) * 100;

        } else if (goalType.equals(
                getString(R.string.goal_maintain_weight)
        )) {

            double difference =
                    Math.abs(latest - goal);

            percentage =
                    100 - ((difference / goal) * 100);

        } else {

            percentage = 0;
        }

        return (int) Math.min(
                Math.max(percentage, 0),
                100
        );
    }

    /**
     * Displays workout and diet recommendations for the
     * user's selected goal type.
     */
    private void updateRecommendations() {

        SharedPreferences preferences =
                getSharedPreferences(
                        "userGoals",
                        MODE_PRIVATE
                );

        String goalType =
                preferences.getString(
                        "goalType",
                        ""
                );

        String sex =
                preferences.getString(
                        "sex",
                        ""
                );

        if (goalType.isEmpty()) {

            tvRecommendations.setText(
                    R.string.set_goal_to_see_recommendations
            );

            return;
        }

        String workoutRecommendations =
                getWorkoutRecommendations(goalType);

        String dietRecommendations =
                getDietRecommendations(goalType);

        String recommendationText =
                getString(
                        R.string.recommendation_detailed_format,
                        goalType,
                        sex,
                        workoutRecommendations,
                        dietRecommendations
                );

        tvRecommendations.setText(
                recommendationText
        );
    }

    /**
     * Returns workout recommendations for each goal type.
     */
    private String getWorkoutRecommendations(
            String goalType
    ) {

        if (goalType.equals(
                getString(R.string.goal_lose_weight)
        )) {

            return getString(
                    R.string.workout_recommendations_lose_weight
            );
        }

        if (goalType.equals(
                getString(R.string.goal_bulk_up)
        )) {

            return getString(
                    R.string.workout_recommendations_bulk_up
            );
        }

        if (goalType.equals(
                getString(R.string.goal_gain_lean_muscle)
        )) {

            return getString(
                    R.string.workout_recommendations_lean_muscle
            );
        }

        if (goalType.equals(
                getString(R.string.goal_maintain_weight)
        )) {

            return getString(
                    R.string.workout_recommendations_maintain
            );
        }

        if (goalType.equals(
                getString(R.string.goal_gain_weight)
        )) {

            return getString(
                    R.string.workout_recommendations_gain_weight
            );
        }

        return getString(
                R.string.recommendations_not_available
        );
    }

    /**
     * Returns diet recommendations for each goal type.
     */
    private String getDietRecommendations(
            String goalType
    ) {

        if (goalType.equals(
                getString(R.string.goal_lose_weight)
        )) {

            return getString(
                    R.string.diet_recommendations_lose_weight
            );
        }

        if (goalType.equals(
                getString(R.string.goal_bulk_up)
        )) {

            return getString(
                    R.string.diet_recommendations_bulk_up
            );
        }

        if (goalType.equals(
                getString(R.string.goal_gain_lean_muscle)
        )) {

            return getString(
                    R.string.diet_recommendations_lean_muscle
            );
        }

        if (goalType.equals(
                getString(R.string.goal_maintain_weight)
        )) {

            return getString(
                    R.string.diet_recommendations_maintain
            );
        }

        if (goalType.equals(
                getString(R.string.goal_gain_weight)
        )) {

            return getString(
                    R.string.diet_recommendations_gain_weight
            );
        }

        return getString(
                R.string.recommendations_not_available
        );
    }
}