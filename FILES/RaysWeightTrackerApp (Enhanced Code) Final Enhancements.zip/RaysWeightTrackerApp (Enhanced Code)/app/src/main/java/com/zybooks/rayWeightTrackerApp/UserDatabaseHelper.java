package com.zybooks.rayWeightTrackerApp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Handles all database operations related to user accounts.
 * Supports creating users, checking for duplicates, and validating login.
 */
public class UserDatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME = "weighttracker.db";
    private static final int VERSION = 1;

    // User table definition
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    public UserDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserTable.COL_USERNAME + " TEXT UNIQUE, " +
                UserTable.COL_PASSWORD + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop and recreate table on upgrade
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        onCreate(db);
    }

    /**
     * Adds a new user to the database.
     * @return true if insert succeeded, false otherwise.
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);

        long result = db.insert(UserTable.TABLE, null, values);
        return result != -1;
    }

    /**
     * Checks if a username already exists.
     */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + UserTable.TABLE +
                " WHERE " + UserTable.COL_USERNAME + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[]{username});

        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    /**
     * Validates login credentials.
     * @return true if username/password match a record.
     */
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + UserTable.TABLE +
                " WHERE " + UserTable.COL_USERNAME + " = ? AND " +
                UserTable.COL_PASSWORD + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        boolean valid = cursor.moveToFirst();
        cursor.close();
        return valid;
    }

    /**
     * Updates username and password for an existing user.
     * @return true if update succeeded.
     */
    public boolean updateUser(String oldUsername, String newUsername, String newPassword) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, newUsername);
        values.put(UserTable.COL_PASSWORD, newPassword);

        int rows = db.update(
                UserTable.TABLE,
                values,
                UserTable.COL_USERNAME + " = ?",
                new String[]{oldUsername}
        );

        return rows > 0;
    }
}
