package com.zybooks.rayWeightTrackerApp.model;

public class Recommendation {
    private long id;
    private long userId;
    private String text;
    private int priorityScore;

    public Recommendation(long id, long userId, String text, int priorityScore) {
        this.id = id;
        this.userId = userId;
        this.text = text;
        this.priorityScore = priorityScore;
    }

    public long getId() { return id; }
    public long getUserId() { return userId; }
    public String getText() { return text; }
    public int getPriorityScore() { return priorityScore; }
}
