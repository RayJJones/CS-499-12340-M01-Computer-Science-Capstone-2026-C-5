package com.zybooks.rayWeightTrackerApp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.rayWeightTrackerApp.data.AppDatabaseHelper;

/**
 * Allows the user to select a goal weight, goal type, and sex.
 */
public class GoalWeightActivity extends AppCompatActivity {

    private EditText etGoalWeight;
    private RadioGroup rgGoalType;
    private RadioGroup rgSex;

    private TextView tvWelcomeUser;

    private AppDatabaseHelper appDb;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        tvWelcomeUser =
                findViewById(
                        R.id.tvWelcomeUser
                );

        etGoalWeight =
                findViewById(
                        R.id.etGoalWeight
                );

        rgGoalType =
                findViewById(
                        R.id.rgGoalType
                );

        rgSex =
                findViewById(
                        R.id.rgSex
                );

        Button btnSaveGoal =
                findViewById(
                        R.id.btnSaveGoal
                );

        Button btnBackHome =
                findViewById(
                        R.id.btnBackHome
                );

        appDb =
                new AppDatabaseHelper(this);

        SharedPreferences session =
                getSharedPreferences(
                        "userSession",
                        MODE_PRIVATE
                );

        userId =
                session.getLong(
                        "userId",
                        1L
                );

        String username =
                appDb.getUsername(userId);

        tvWelcomeUser.setText(
                "Hello " + username + "!"
        );

        loadSavedSelections();

        btnSaveGoal.setOnClickListener(
                v -> saveGoal()
        );

        btnBackHome.setOnClickListener(
                v -> finish()
        );

        loadSavedSelections();

        btnSaveGoal.setOnClickListener(v -> saveGoal());
        btnBackHome.setOnClickListener(v -> finish());
    }

    /**
     * Restores the saved goal type and sex when the user returns.
     */
    private void loadSavedSelections() {
        SharedPreferences preferences =
                getSharedPreferences("userGoals", MODE_PRIVATE);

        String savedGoal =
                preferences.getString("goalType", "");

        String savedSex =
                preferences.getString("sex", "");

        if (getString(R.string.goal_lose_weight).equals(savedGoal)) {
            rgGoalType.check(R.id.rbLoseWeight);

        } else if (getString(R.string.goal_bulk_up).equals(savedGoal)) {
            rgGoalType.check(R.id.rbBulkUp);

        } else if (getString(R.string.goal_gain_lean_muscle)
                .equals(savedGoal)) {
            rgGoalType.check(R.id.rbGainLeanMuscle);

        } else if (getString(R.string.goal_maintain_weight)
                .equals(savedGoal)) {
            rgGoalType.check(R.id.rbMaintain);

        } else if (getString(R.string.goal_gain_weight)
                .equals(savedGoal)) {
            rgGoalType.check(R.id.rbGainWeight);
        }

        if (getString(R.string.male).equals(savedSex)) {
            rgSex.check(R.id.rbMale);

        } else if (getString(R.string.female).equals(savedSex)) {
            rgSex.check(R.id.rbFemale);
        }
    }

    /**
     * Validates and saves the goal information.
     */
    private void saveGoal() {
        String goalWeightText =
                etGoalWeight.getText().toString().trim();

        if (goalWeightText.isEmpty()) {
            etGoalWeight.setError(
                    getString(R.string.error_goal_weight_required)
            );
            etGoalWeight.requestFocus();
            return;
        }

        double goalWeight;

        try {
            goalWeight = Double.parseDouble(goalWeightText);

        } catch (NumberFormatException exception) {
            etGoalWeight.setError(
                    getString(R.string.error_invalid_weight)
            );
            etGoalWeight.requestFocus();
            return;
        }

        if (goalWeight <= 0) {
            etGoalWeight.setError(
                    getString(R.string.error_goal_weight_positive)
            );
            etGoalWeight.requestFocus();
            return;
        }

        int selectedGoalId =
                rgGoalType.getCheckedRadioButtonId();

        if (selectedGoalId == -1) {
            Toast.makeText(
                    this,
                    R.string.error_select_goal_type,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        int selectedSexId =
                rgSex.getCheckedRadioButtonId();

        if (selectedSexId == -1) {
            Toast.makeText(
                    this,
                    R.string.error_select_sex,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        RadioButton selectedGoal =
                findViewById(selectedGoalId);

        RadioButton selectedSex =
                findViewById(selectedSexId);

        String goalType =
                selectedGoal.getText().toString();

        String sex =
                selectedSex.getText().toString();

        boolean saved = appDb.setGoal(
                userId,
                goalType,
                goalWeight,
                30
        );

        if (!saved) {
            Toast.makeText(
                    this,
                    R.string.goal_save_failed,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        SharedPreferences preferences =
                getSharedPreferences("userGoals", MODE_PRIVATE);

        preferences.edit()
                .putString("goalType", goalType)
                .putString("sex", sex)
                .apply();

        Toast.makeText(
                this,
                R.string.goal_saved_successfully,
                Toast.LENGTH_SHORT
        ).show();

        finish();
    }
}