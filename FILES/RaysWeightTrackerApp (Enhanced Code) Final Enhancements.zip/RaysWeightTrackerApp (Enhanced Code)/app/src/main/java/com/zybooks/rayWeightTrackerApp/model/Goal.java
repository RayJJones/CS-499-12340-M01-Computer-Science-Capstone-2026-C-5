package com.zybooks.rayWeightTrackerApp.model;

public class Goal {
    private long id;
    private long userId;
    private String goalType;
    private int targetWeight;
    private int durationDays;

    public Goal(long id, long userId, String goalType, int targetWeight, int durationDays) {
        this.id = id;
        this.userId = userId;
        this.goalType = goalType;
        this.targetWeight = targetWeight;
        this.durationDays = durationDays;
    }

    public long getId() { return id; }
    public long getUserId() { return userId; }
    public String getGoalType() { return goalType; }
    public int getTargetWeight() { return targetWeight; }
    public int getDurationDays() { return durationDays; }
}
