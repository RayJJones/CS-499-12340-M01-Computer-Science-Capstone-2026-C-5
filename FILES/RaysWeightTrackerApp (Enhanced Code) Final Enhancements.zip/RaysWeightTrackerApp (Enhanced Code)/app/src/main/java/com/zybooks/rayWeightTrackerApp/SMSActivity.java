package com.zybooks.rayWeightTrackerApp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Handles SMS permission requests and sends a test SMS
 * when permission is granted.
 */
public class SMSActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private Button btnEnableSMS;
    private TextView tvPermissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Initialize UI
        btnEnableSMS = findViewById(R.id.btnEnableSMS);
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);

        updatePermissionStatus();

        // Request SMS permission
        btnEnableSMS.setOnClickListener(v -> requestSmsPermission());
    }

    /**
     * Updates UI text based on current SMS permission state.
     */
    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            tvPermissionStatus.setText(R.string.sms_granted);
        } else {
            tvPermissionStatus.setText(R.string.sms_not_granted);
        }
    }

    /**
     * Requests SMS permission from the user.
     */
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            sendTestSMS();

        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    /**
     * Handles the result of the SMS permission request.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
                sendTestSMS();

            } else {
                Toast.makeText(this, "Permission denied. SMS disabled.", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
            }
        }
    }

    /**
     * Sends a test SMS message to confirm functionality.
     */
    private void sendTestSMS() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    "5554",
                    null,
                    "Weight Tracker Alert: SMS notifications enabled!",
                    null,
                    null
            );

            Toast.makeText(this, "Test SMS sent!", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}
