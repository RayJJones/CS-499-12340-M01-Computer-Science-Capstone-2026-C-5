package com.zybooks.rayWeightTrackerApp.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.zybooks.rayWeightTrackerApp.model.WorkoutHistory;
import com.zybooks.rayWeightTrackerApp.security.PasswordUtils;

import java.util.ArrayList;

/**
 * Central database helper for the Weight Tracker application.
 *
 * This helper manages the following relational tables:
 * - Users
 * - Goals
 * - WorkoutHistory
 * - WorkoutEntries
 * - Recommendations
 *
 * The helper also provides methods for account creation,
 * login validation, weight-history management, progress
 * comparisons, and goal management.
 */
public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 3;

    /**
     * Default user retained for compatibility with older code.
     */
    private static final long DEFAULT_USER_ID = 1L;

    private static final String TABLE_USERS = "Users";
    private static final String TABLE_GOALS = "Goals";
    private static final String TABLE_WORKOUT_HISTORY = "WorkoutHistory";
    private static final String TABLE_WORKOUT_ENTRIES = "WorkoutEntries";
    private static final String TABLE_RECOMMENDATIONS = "Recommendations";

    public AppDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    /**
     * Enables SQLite foreign-key enforcement.
     */
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    /**
     * Creates all application tables and indexes.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        createUsersTable(db);
        insertDefaultUser(db);
        createGoalsTable(db);
        createWorkoutHistoryTable(db);
        createWorkoutEntriesTable(db);
        createRecommendationsTable(db);
        createIndexes(db);
    }

    /**
     * Creates the Users table.
     */
    private void createUsersTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "username TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                        "email TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                        "password_hash TEXT NOT NULL" +
                        ")"
        );
    }

    /**
     * Creates a default development user with user ID 1.
     *
     * This keeps older parts of the application working while
     * user-specific database methods are being implemented.
     */
    private void insertDefaultUser(SQLiteDatabase db) {
        ContentValues values = new ContentValues();

        values.put("name", "Default User");
        values.put("username", "default");
        values.put("email", "default@weighttracker.local");
        values.put(
                "password_hash",
                PasswordUtils.hashPassword("Password1")
        );

        db.insertOrThrow(
                TABLE_USERS,
                null,
                values
        );
    }

    /**
     * Creates the Goals table.
     */
    private void createGoalsTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_GOALS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "goal_type TEXT NOT NULL, " +
                        "target_weight REAL NOT NULL " +
                        "CHECK(target_weight > 0), " +
                        "duration_days INTEGER NOT NULL DEFAULT 30 " +
                        "CHECK(duration_days > 0), " +
                        "FOREIGN KEY(user_id) REFERENCES " +
                        TABLE_USERS + "(id) ON DELETE CASCADE" +
                        ")"
        );
    }

    /**
     * Creates the WorkoutHistory table.
     */
    private void createWorkoutHistoryTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_WORKOUT_HISTORY + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "date TEXT NOT NULL, " +
                        "weight REAL NOT NULL CHECK(weight > 0), " +
                        "steps INTEGER NOT NULL DEFAULT 0 " +
                        "CHECK(steps >= 0), " +
                        "FOREIGN KEY(user_id) REFERENCES " +
                        TABLE_USERS + "(id) ON DELETE CASCADE" +
                        ")"
        );
    }

    /**
     * Creates the WorkoutEntries table.
     */
    private void createWorkoutEntriesTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_WORKOUT_ENTRIES + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "date TEXT NOT NULL, " +
                        "type TEXT NOT NULL, " +
                        "duration_minutes INTEGER " +
                        "CHECK(duration_minutes >= 0), " +
                        "intensity INTEGER " +
                        "CHECK(intensity BETWEEN 1 AND 5), " +
                        "FOREIGN KEY(user_id) REFERENCES " +
                        TABLE_USERS + "(id) ON DELETE CASCADE" +
                        ")"
        );
    }

    /**
     * Creates the Recommendations table.
     */
    private void createRecommendationsTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_RECOMMENDATIONS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "text TEXT NOT NULL, " +
                        "priority_score INTEGER NOT NULL, " +
                        "FOREIGN KEY(user_id) REFERENCES " +
                        TABLE_USERS + "(id) ON DELETE CASCADE" +
                        ")"
        );
    }

    /**
     * Creates indexes for frequently queried columns.
     */
    private void createIndexes(SQLiteDatabase db) {
        db.execSQL(
                "CREATE INDEX idx_users_username ON " +
                        TABLE_USERS + "(username)"
        );

        db.execSQL(
                "CREATE INDEX idx_user_history ON " +
                        TABLE_WORKOUT_HISTORY + "(user_id)"
        );

        db.execSQL(
                "CREATE INDEX idx_user_goals ON " +
                        TABLE_GOALS + "(user_id)"
        );

        db.execSQL(
                "CREATE INDEX idx_history_user_id ON " +
                        TABLE_WORKOUT_HISTORY + "(user_id, id DESC)"
        );
    }

    /**
     * Recreates the database when its version changes.
     *
     * This development approach deletes existing records.
     * A production application should use database migrations.
     */
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {
        db.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_RECOMMENDATIONS
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_WORKOUT_ENTRIES
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_WORKOUT_HISTORY
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_GOALS
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_USERS
        );

        onCreate(db);
    }

    // =========================================================
    // USER ACCOUNT METHODS
    // =========================================================

    /**
     * Checks whether a username or email is already registered.
     *
     * @param username username being checked
     * @param email email address being checked
     * @return true when either value already exists
     */
    public boolean accountExists(
            String username,
            String email
    ) {
        if (username == null || email == null) {
            return false;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{"id"},
                "username = ? OR email = ?",
                new String[]{
                        username.trim(),
                        email.trim()
                },
                null,
                null,
                null,
                "1"
        )) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Creates a user account and stores a hashed password.
     *
     * @param name user's full name
     * @param username unique username
     * @param email unique email address
     * @param plainPassword unencrypted password received from the form
     * @return new user ID, or -1 if creation fails
     */
    public long createAccount(
            String name,
            String username,
            String email,
            String plainPassword
    ) {
        if (name == null
                || name.trim().isEmpty()
                || username == null
                || username.trim().isEmpty()
                || email == null
                || email.trim().isEmpty()
                || plainPassword == null
                || plainPassword.isEmpty()) {

            return -1;
        }

        if (accountExists(username, email)) {
            return -1;
        }

        String passwordHash =
                PasswordUtils.hashPassword(plainPassword);

        if (passwordHash.isEmpty()) {
            return -1;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("username", username.trim());
        values.put("email", email.trim());
        values.put("password_hash", passwordHash);

        return db.insert(
                TABLE_USERS,
                null,
                values
        );
    }

    /**
     * Validates a username and password.
     *
     * @param username username entered on the login screen
     * @param plainPassword password entered on the login screen
     * @return matching user ID, or -1 when login fails
     */
    public long validateLogin(
            String username,
            String plainPassword
    ) {
        if (username == null
                || username.trim().isEmpty()
                || plainPassword == null
                || plainPassword.isEmpty()) {

            return -1;
        }

        String passwordHash =
                PasswordUtils.hashPassword(plainPassword);

        if (passwordHash.isEmpty()) {
            return -1;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{"id"},
                "username = ? AND password_hash = ?",
                new String[]{
                        username.trim(),
                        passwordHash
                },
                null,
                null,
                null,
                "1"
        )) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(
                        cursor.getColumnIndexOrThrow("id")
                );
            }
        }

        return -1;
    }

    // =========================================================
    // WORKOUT HISTORY METHODS
    // =========================================================

    /**
     * Adds a weight-and-steps record for a user.
     *
     * @return true when the record is inserted successfully
     */
    public boolean addWorkoutHistory(
            long userId,
            String date,
            float weight,
            int steps
    ) {
        if (userId <= 0
                || date == null
                || date.trim().isEmpty()
                || weight <= 0
                || steps < 0) {

            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("date", date.trim());
        values.put("weight", weight);
        values.put("steps", steps);

        long result = db.insert(
                TABLE_WORKOUT_HISTORY,
                null,
                values
        );

        return result != -1;
    }

    /**
     * Returns all weight-history entries for one user.
     *
     * Records are ordered by ID in descending order so the
     * newest inserted record appears first.
     */
    public ArrayList<WorkoutHistory> getWorkoutHistory(
            long userId
    ) {
        ArrayList<WorkoutHistory> historyList =
                new ArrayList<>();

        if (userId <= 0) {
            return historyList;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_WORKOUT_HISTORY,
                new String[]{
                        "id",
                        "user_id",
                        "date",
                        "weight",
                        "steps"
                },
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                "id DESC"
        )) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(
                        cursor.getColumnIndexOrThrow("id")
                );

                long historyUserId = cursor.getLong(
                        cursor.getColumnIndexOrThrow("user_id")
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("date")
                );

                float weight = cursor.getFloat(
                        cursor.getColumnIndexOrThrow("weight")
                );

                int steps = cursor.getInt(
                        cursor.getColumnIndexOrThrow("steps")
                );

                historyList.add(
                        new WorkoutHistory(
                                id,
                                historyUserId,
                                date,
                                weight,
                                steps
                        )
                );
            }
        }

        return historyList;
    }

    /**
     * Compatibility method that loads history for the default user.
     *
     * New activities should call getWorkoutHistory(userId).
     */
    public ArrayList<WorkoutHistory> getAllWorkoutHistory() {
        return getWorkoutHistory(DEFAULT_USER_ID);
    }

    /**
     * Returns the newest weight belonging to one user.
     *
     * @return newest weight, or zero when no entry exists
     */
    public float getLatestWorkoutWeight(long userId) {
        if (userId <= 0) {
            return 0;
        }

        SQLiteDatabase db = getReadableDatabase();
        float latestWeight = 0;

        try (Cursor cursor = db.query(
                TABLE_WORKOUT_HISTORY,
                new String[]{"weight"},
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                "id DESC",
                "1"
        )) {
            if (cursor.moveToFirst()) {
                latestWeight = cursor.getFloat(
                        cursor.getColumnIndexOrThrow("weight")
                );
            }
        }

        return latestWeight;
    }

    /**
     * Compatibility method that returns the default user's
     * latest weight.
     */
    public float getLatestWorkoutWeight() {
        return getLatestWorkoutWeight(DEFAULT_USER_ID);
    }

    /**
     * Returns the second-newest weight belonging to one user.
     *
     * This supports progress, setback, and same-weight messages.
     *
     * @return previous weight, or zero when fewer than two entries exist
     */
    public float getPreviousWorkoutWeight(long userId) {
        if (userId <= 0) {
            return 0;
        }

        SQLiteDatabase db = getReadableDatabase();
        float previousWeight = 0;

        try (Cursor cursor = db.query(
                TABLE_WORKOUT_HISTORY,
                new String[]{"weight"},
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                "id DESC",
                "2"
        )) {
            if (cursor.moveToFirst()
                    && cursor.moveToNext()) {

                previousWeight = cursor.getFloat(
                        cursor.getColumnIndexOrThrow("weight")
                );
            }
        }

        return previousWeight;
    }

    /**
     * Compatibility method that returns the default user's
     * previous weight.
     */
    public float getPreviousWorkoutWeight() {
        return getPreviousWorkoutWeight(DEFAULT_USER_ID);
    }

    /**
     * Updates a history record belonging to a specific user.
     *
     * Including user_id in the selection prevents one user
     * from changing another user's record.
     *
     * @return true when a matching record is updated
     */
    public boolean updateWorkoutHistory(
            long id,
            long userId,
            String date,
            float weight,
            int steps
    ) {
        if (id <= 0
                || userId <= 0
                || date == null
                || date.trim().isEmpty()
                || weight <= 0
                || steps < 0) {

            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("date", date.trim());
        values.put("weight", weight);
        values.put("steps", steps);

        int rowsUpdated = db.update(
                TABLE_WORKOUT_HISTORY,
                values,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(id),
                        String.valueOf(userId)
                }
        );

        return rowsUpdated > 0;
    }

    /**
     * Compatibility method for older edit code.
     *
     * New code should include the logged-in user ID.
     */
    public boolean updateWorkoutHistory(
            long id,
            String date,
            float weight,
            int steps
    ) {
        return updateWorkoutHistory(
                id,
                DEFAULT_USER_ID,
                date,
                weight,
                steps
        );
    }

    /**
     * Deletes a history record belonging to a specific user.
     *
     * Including user_id in the selection prevents one user
     * from deleting another user's record.
     *
     * @return true when a matching record is deleted
     */
    public boolean deleteWorkoutHistory(
            long id,
            long userId
    ) {
        if (id <= 0 || userId <= 0) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_WORKOUT_HISTORY,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(id),
                        String.valueOf(userId)
                }
        );

        return rowsDeleted > 0;
    }

    /**
     * Compatibility method for older delete code.
     *
     * New code should include the logged-in user ID.
     */
    public boolean deleteWorkoutHistory(long id) {
        return deleteWorkoutHistory(
                id,
                DEFAULT_USER_ID
        );
    }

    // =========================================================
    // GOAL METHODS
    // =========================================================

    /**
     * Saves or replaces the active goal for one user.
     *
     * The current design stores one active goal per user.
     *
     * @return true when the goal is saved successfully
     */
    public boolean setGoal(
            long userId,
            String goalType,
            double goalWeight,
            int durationDays
    ) {
        if (userId <= 0
                || goalType == null
                || goalType.trim().isEmpty()
                || goalWeight <= 0
                || durationDays <= 0) {

            return false;
        }

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();

        try {
            db.delete(
                    TABLE_GOALS,
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    }
            );

            ContentValues values = new ContentValues();
            values.put("user_id", userId);
            values.put("goal_type", goalType.trim());
            values.put("target_weight", goalWeight);
            values.put("duration_days", durationDays);

            long result = db.insert(
                    TABLE_GOALS,
                    null,
                    values
            );

            if (result == -1) {
                return false;
            }

            db.setTransactionSuccessful();
            return true;

        } finally {
            db.endTransaction();
        }
    }

    /**
     * Compatibility method that saves a general weight goal
     * for the default user.
     */
    public boolean setGoalWeight(double goalWeight) {
        return setGoal(
                DEFAULT_USER_ID,
                "General",
                goalWeight,
                30
        );
    }

    /**
     * Returns the current goal weight for one user.
     *
     * @return current goal weight, or zero when no goal exists
     */
    public double getGoalWeight(long userId) {
        if (userId <= 0) {
            return 0;
        }

        SQLiteDatabase db = getReadableDatabase();
        double goalWeight = 0;

        try (Cursor cursor = db.query(
                TABLE_GOALS,
                new String[]{"target_weight"},
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                "id DESC",
                "1"
        )) {
            if (cursor.moveToFirst()) {
                goalWeight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow(
                                "target_weight"
                        )
                );
            }
        }

        return goalWeight;
    }

    /**
     * Returns the goal type for one user.
     *
     * @return goal type, or an empty string when no goal exists
     */
    public String getGoalType(long userId) {
        if (userId <= 0) {
            return "";
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_GOALS,
                new String[]{"goal_type"},
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                "id DESC",
                "1"
        )) {
            if (cursor.moveToFirst()) {
                return cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "goal_type"
                        )
                );
            }
        }

        return "";
    }
    /**
     * Returns the username associated with a user ID.
     *
     * Used by the dashboard, history screen,
     * add-weight screen, and goal screen to display:
     * "Hello username!"
     *
     * @param userId logged-in user's ID
     * @return username if found, otherwise "User"
     */
    public String getUsername(long userId) {

        if (userId <= 0) {
            return "User";
        }

        SQLiteDatabase db =
                getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{"username"},
                "id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                null,
                "1"
        )) {

            if (cursor.moveToFirst()) {

                return cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "username"
                        )
                );
            }
        }

        return "User";
    }
    /**
     * Compatibility method that returns the default user's goal.
     */
    public double getGoalWeight() {
        return getGoalWeight(DEFAULT_USER_ID);
    }
}