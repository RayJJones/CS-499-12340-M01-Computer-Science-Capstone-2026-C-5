package com.zybooks.rayWeightTrackerApp;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.rayWeightTrackerApp.data.AppDatabaseHelper;

/**
 * Screen used to create and save a new account.
 */
public class CreateAccountActivity extends AppCompatActivity {

    private EditText etFullName;
    private EditText etCreateUsername;
    private EditText etEmail;
    private EditText etCreatePassword;
    private EditText etConfirmPassword;

    private AppDatabaseHelper appDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_create_account);

        appDb = new AppDatabaseHelper(this);

        etFullName = findViewById(R.id.etFullName);

        etCreateUsername =
                findViewById(R.id.etCreateUsername);

        etEmail = findViewById(R.id.etEmail);

        etCreatePassword =
                findViewById(R.id.etCreatePassword);

        etConfirmPassword =
                findViewById(R.id.etConfirmPassword);

        Button btnSaveAccount =
                findViewById(R.id.btnSaveAccount);

        Button btnCancelAccount =
                findViewById(R.id.btnCancelAccount);

        btnSaveAccount.setOnClickListener(
                v -> createAccount()
        );

        btnCancelAccount.setOnClickListener(
                v -> finish()
        );
    }

    /**
     * Validates fields and saves a new account.
     */
    private void createAccount() {
        String name =
                etFullName.getText().toString().trim();

        String username =
                etCreateUsername.getText().toString().trim();

        String email =
                etEmail.getText().toString().trim();

        String password =
                etCreatePassword.getText().toString();

        String confirmedPassword =
                etConfirmPassword.getText().toString();

        if (name.isEmpty()) {
            etFullName.setError(
                    getString(R.string.error_name_required)
            );

            etFullName.requestFocus();
            return;
        }

        if (username.length() < 3) {
            etCreateUsername.setError(
                    getString(R.string.error_username_length)
            );

            etCreateUsername.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches()) {

            etEmail.setError(
                    getString(R.string.error_valid_email)
            );

            etEmail.requestFocus();
            return;
        }

        if (password.length() < 8) {
            etCreatePassword.setError(
                    getString(R.string.error_password_length)
            );

            etCreatePassword.requestFocus();
            return;
        }

        if (!password.matches(".*[A-Za-z].*")
                || !password.matches(".*\\d.*")) {

            etCreatePassword.setError(
                    getString(R.string.error_password_rules)
            );

            etCreatePassword.requestFocus();
            return;
        }

        if (!password.equals(confirmedPassword)) {
            etConfirmPassword.setError(
                    getString(R.string.error_passwords_match)
            );

            etConfirmPassword.requestFocus();
            return;
        }

        if (appDb.accountExists(username, email)) {
            Toast.makeText(
                    this,
                    R.string.account_already_exists,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        long userId = appDb.createAccount(
                name,
                username,
                email,
                password
        );

        if (userId == -1) {
            Toast.makeText(
                    this,
                    R.string.account_creation_failed,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Toast.makeText(
                this,
                R.string.account_creation_successful,
                Toast.LENGTH_SHORT
        ).show();

        finish();
    }

}
