package com.zybooks.rayWeightTrackerApp.logic;

import com.zybooks.rayWeightTrackerApp.model.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class RecommendationEngine {

    public List<Recommendation> generateRecommendations(
            User user,
            Goal goal,
            List<WorkoutHistory> history,
            List<WorkoutEntry> workouts
    ) {
        List<Recommendation> recs = new ArrayList<>();

        int consistencyScore = calculateConsistency(history);
        int activityScore = calculateActivityLevel(workouts);
        int progressScore = calculateProgressTrend(history);

        int totalScore = (int) (progressScore * 0.4
                + activityScore * 0.3
                + consistencyScore * 0.3);

        if (totalScore < 30) {
            recs.add(new Recommendation(0, user.getId(),
                    "Your progress is slow. Try adding one more workout per week.", 80));
            recs.add(new Recommendation(0, user.getId(),
                    "Consider lowering calorie intake slightly.", 70));
        } else if (totalScore < 60) {
            recs.add(new Recommendation(0, user.getId(),
                    "You’re making steady progress. Add light cardio.", 60));
        } else {
            recs.add(new Recommendation(0, user.getId(),
                    "Great progress! Maintain your current plan.", 50));
        }

        Collections.sort(recs, new Comparator<Recommendation>() {
            @Override
            public int compare(Recommendation r1, Recommendation r2) {
                return Integer.compare(r2.getPriorityScore(), r1.getPriorityScore());
            }
        });

        return recs;
    }

    private int calculateConsistency(List<WorkoutHistory> history) {
        if (history == null || history.isEmpty()) return 0;
        return Math.min(history.size() * 5, 100);
    }

    private int calculateActivityLevel(List<WorkoutEntry> workouts) {
        if (workouts == null || workouts.isEmpty()) return 0;
        int total = 0;
        for (WorkoutEntry w : workouts) {
            total += w.getDurationMinutes() * w.getIntensity();
        }
        return Math.min(total / 10, 100);
    }

    private int calculateProgressTrend(List<WorkoutHistory> history) {
        if (history == null || history.size() < 2) return 0;
        float start = history.get(0).getWeight();
        float end = history.get(history.size() - 1).getWeight();
        float diff = start - end;

        if (diff <= 0) return 10;
        if (diff < 5) return 40;
        if (diff < 10) return 70;
        return 100;
    }
}
