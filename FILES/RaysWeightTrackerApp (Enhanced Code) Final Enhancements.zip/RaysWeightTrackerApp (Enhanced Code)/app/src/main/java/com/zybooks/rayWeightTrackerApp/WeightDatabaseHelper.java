package com.zybooks.rayWeightTrackerApp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Handles all database operations for weight entries.
 * Supports adding, retrieving, updating, and deleting weight records.
 */
public class WeightDatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME = "weighttracker_weights.db";
    private static final int VERSION = 1;

    /**
     * Table and column definitions for weight entries.
     */
    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }

    public WeightDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create weights table
        db.execSQL("CREATE TABLE " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                WeightTable.COL_DATE + " TEXT, " +
                WeightTable.COL_WEIGHT + " REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop and recreate table on upgrade
        db.execSQL("DROP TABLE IF EXISTS " + WeightTable.TABLE);
        onCreate(db);
    }

    /**
     * Inserts a new weight entry into the database.
     * @return true if insert succeeded.
     */
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_WEIGHT, weight);

        long result = db.insert(WeightTable.TABLE, null, values);
        return result != -1;
    }

    /**
     * Retrieves all weight entries in descending order (newest first).
     */
    public ArrayList<WeightEntry> getAllWeights() {
        ArrayList<WeightEntry> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + WeightTable.TABLE +
                        " ORDER BY " + WeightTable.COL_ID + " DESC",
                null
        );

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String date = cursor.getString(1);
                double weight = cursor.getDouble(2);

                list.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    /**
     * Deletes a weight entry by ID.
     * @return true if a row was deleted.
     */
    public boolean deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                WeightTable.TABLE,
                WeightTable.COL_ID + " = ?",
                new String[]{String.valueOf(id)}
        );

        return rowsDeleted > 0;
    }

    /**
     * Updates an existing weight entry.
     * @return true if update succeeded.
     */
    public boolean updateWeight(long id, double weight, String date) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight);
        values.put(WeightTable.COL_DATE, date);

        int rows = db.update(
                WeightTable.TABLE,
                values,
                WeightTable.COL_ID + " = ?",
                new String[]{String.valueOf(id)}
        );

        return rows > 0;
    }

    /**
     * Retrieves the most recent weight entry.
     * @return latest weight or 0 if none exist.
     */
    public double getLatestWeight() {
        SQLiteDatabase db = getReadableDatabase();
        double weight = 0;

        Cursor cursor = db.rawQuery(
                "SELECT " + WeightTable.COL_WEIGHT +
                        " FROM " + WeightTable.TABLE +
                        " ORDER BY " + WeightTable.COL_ID + " DESC LIMIT 1",
                null
        );

        if (cursor.moveToFirst()) {
            weight = cursor.getDouble(0);
        }

        cursor.close();
        return weight;
    }
}
