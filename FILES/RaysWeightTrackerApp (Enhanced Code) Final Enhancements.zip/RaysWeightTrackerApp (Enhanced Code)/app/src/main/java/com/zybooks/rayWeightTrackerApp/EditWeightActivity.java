package com.zybooks.rayWeightTrackerApp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.rayWeightTrackerApp.data.AppDatabaseHelper;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Activity for editing an existing weight-history entry.
 *
 * Receives the entry information from WeightHistoryActivity,
 * validates the updated weight, steps, and date, and updates
 * the logged-in user's record in AppDatabaseHelper.
 */
public class EditWeightActivity extends AppCompatActivity {

    private EditText etEditWeight;
    private EditText etEditSteps;
    private EditText etEditDate;

    private AppDatabaseHelper dbHelper;

    private long entryId;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight);

        /*
         * Connect the Java fields to the views in
         * activity_edit_weight.xml.
         */
        etEditWeight =
                findViewById(R.id.etEditWeight);

        etEditSteps =
                findViewById(R.id.etEditSteps);

        etEditDate =
                findViewById(R.id.etEditDate);

        Button btnSaveEdit =
                findViewById(R.id.btnSaveEdit);

        Button btnCancelEdit =
                findViewById(R.id.btnCancelEdit);

        /*
         * Use the same unified database helper used by
         * AddWeightActivity and WeightHistoryActivity.
         */
        dbHelper =
                new AppDatabaseHelper(this);

        /*
         * Retrieve the currently logged-in user's ID.
         */
        SharedPreferences session =
                getSharedPreferences(
                        "userSession",
                        MODE_PRIVATE
                );

        userId =
                session.getLong(
                        "userId",
                        1L
                );

        /*
         * Retrieve the existing record information passed
         * from WeightHistoryActivity.
         */
        Intent intent =
                getIntent();

        entryId =
                intent.getLongExtra(
                        "id",
                        -1L
                );

        float existingWeight =
                intent.getFloatExtra(
                        "weight",
                        0.0f
                );

        int existingSteps =
                intent.getIntExtra(
                        "steps",
                        0
                );

        String existingDate =
                intent.getStringExtra(
                        "date"
                );

        /*
         * Stop the activity if no valid history ID was supplied.
         */
        if (entryId <= 0) {
            Toast.makeText(
                    this,
                    R.string.invalid_history_entry,
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        /*
         * Pre-fill the form with the existing values.
         */
        etEditWeight.setText(
                String.valueOf(existingWeight)
        );

        etEditSteps.setText(
                String.valueOf(existingSteps)
        );

        if (existingDate != null) {
            etEditDate.setText(existingDate);
        }

        /*
         * Save or cancel the edit.
         */
        btnSaveEdit.setOnClickListener(
                view -> saveUpdatedEntry()
        );

        btnCancelEdit.setOnClickListener(
                view -> finish()
        );
    }

    /**
     * Validates the updated weight, steps, and date,
     * then saves the changes.
     */
    private void saveUpdatedEntry() {

        String newWeightText =
                etEditWeight
                        .getText()
                        .toString()
                        .trim();

        String newStepsText =
                etEditSteps
                        .getText()
                        .toString()
                        .trim();

        String newDate =
                etEditDate
                        .getText()
                        .toString()
                        .trim();

        /*
         * Validate the weight.
         */
        if (newWeightText.isEmpty()) {
            etEditWeight.setError(
                    getString(
                            R.string.error_weight_required
                    )
            );

            etEditWeight.requestFocus();
            return;
        }

        float newWeight;

        try {
            newWeight =
                    Float.parseFloat(
                            newWeightText
                    );

        } catch (NumberFormatException exception) {
            etEditWeight.setError(
                    getString(
                            R.string.error_invalid_weight
                    )
            );

            etEditWeight.requestFocus();
            return;
        }

        if (newWeight <= 0) {
            etEditWeight.setError(
                    getString(
                            R.string.error_weight_positive
                    )
            );

            etEditWeight.requestFocus();
            return;
        }

        /*
         * Validate the steps.
         */
        if (newStepsText.isEmpty()) {
            etEditSteps.setError(
                    getString(
                            R.string.error_steps_required
                    )
            );

            etEditSteps.requestFocus();
            return;
        }

        int newSteps;

        try {
            newSteps =
                    Integer.parseInt(
                            newStepsText
                    );

        } catch (NumberFormatException exception) {
            etEditSteps.setError(
                    getString(
                            R.string.error_invalid_steps
                    )
            );

            etEditSteps.requestFocus();
            return;
        }

        if (newSteps < 0) {
            etEditSteps.setError(
                    getString(
                            R.string.error_steps_negative
                    )
            );

            etEditSteps.requestFocus();
            return;
        }

        /*
         * Validate the date.
         */
        if (newDate.isEmpty()) {
            etEditDate.setError(
                    getString(
                            R.string.error_date_required
                    )
            );

            etEditDate.requestFocus();
            return;
        }

        if (!isValidDate(newDate)) {
            etEditDate.setError(
                    getString(
                            R.string.error_date_format
                    )
            );

            etEditDate.requestFocus();
            return;
        }

        /*
         * Update the matching record belonging to the
         * currently logged-in user.
         */
        boolean updated =
                dbHelper.updateWorkoutHistory(
                        entryId,
                        userId,
                        newDate,
                        newWeight,
                        newSteps
                );

        if (updated) {
            Toast.makeText(
                    this,
                    R.string.weight_steps_updated,
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {
            Toast.makeText(
                    this,
                    R.string.weight_update_failed,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Confirms that the entered date exactly follows
     * MM/DD/YYYY and represents a real calendar date.
     */
    private boolean isValidDate(String dateText) {

        if (!dateText.matches(
                "\\d{2}/\\d{2}/\\d{4}"
        )) {
            return false;
        }

        SimpleDateFormat dateFormat =
                new SimpleDateFormat(
                        "MM/dd/yyyy",
                        Locale.US
                );

        dateFormat.setLenient(false);

        ParsePosition position =
                new ParsePosition(0);

        return dateFormat.parse(
                dateText,
                position
        ) != null
                && position.getIndex()
                == dateText.length();
    }
}