package com.zybooks.rayWeightTrackerApp.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * Utility class for creating password hashes.
 */
public final class PasswordUtils {

    private PasswordUtils() {
        // Prevents this utility class from being instantiated.
    }

    public static String hashPassword(String plainText) {

        if (plainText == null) {
            return "";
        }

        try {
            MessageDigest md =
                    MessageDigest.getInstance("SHA-256");

            byte[] bytes = md.digest(
                    plainText.getBytes(StandardCharsets.UTF_8)
            );

            StringBuilder sb = new StringBuilder();

            for (byte b : bytes) {
                sb.append(
                        String.format(
                                Locale.US,
                                "%02x",
                                b
                        )
                );
            }

            return sb.toString();

        } catch (Exception e) {
            return "";
        }
    }
}
