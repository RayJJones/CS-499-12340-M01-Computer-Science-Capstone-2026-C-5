package com.zybooks.rayWeightTrackerApp.model;

public class WorkoutEntry {
    private long id;
    private long userId;
    private String date;
    private String type;
    private int durationMinutes;
    private int intensity;

    public WorkoutEntry(long id, long userId, String date, String type, int durationMinutes, int intensity) {
        this.id = id;
        this.userId = userId;
        this.date = date;
        this.type = type;
        this.durationMinutes = durationMinutes;
        this.intensity = intensity;
    }

    public long getId() { return id; }
    public long getUserId() { return userId; }
    public String getDate() { return date; }
    public String getType() { return type; }
    public int getDurationMinutes() { return durationMinutes; }
    public int getIntensity() { return intensity; }
}
