package com.zybooks.rayWeightTrackerApp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.rayWeightTrackerApp.data.AppDatabaseHelper;
import com.zybooks.rayWeightTrackerApp.model.WorkoutHistory;

import java.util.ArrayList;

/**
 * Displays a list of all saved workout history entries.
 * Allows users to edit or delete individual entries.
 */
public class WeightHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewHistory;
    private WeightAdapter adapter;
    private ArrayList<WorkoutHistory> historyList;

    private TextView tvWelcomeUser;

    private AppDatabaseHelper dbHelper;

    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_history);

        tvWelcomeUser =
                findViewById(
                        R.id.tvWelcomeUser
                );

        recyclerViewHistory =
                findViewById(R.id.recyclerViewHistory);

        Button btnBackHome =
                findViewById(R.id.btnBackHome);

        btnBackHome.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                this,
                                DashboardActivity.class
                        )
                )
        );

        dbHelper = new AppDatabaseHelper(this);

        SharedPreferences session =
                getSharedPreferences(
                        "userSession",
                        MODE_PRIVATE
                );

        userId = session.getLong(
                "userId",
                1L
        );

        String username =
                dbHelper.getUsername(userId);

        tvWelcomeUser.setText(
                "Hello " + username + "!"
        );

        loadHistory();
    }

    /**
     * Loads the current user's weight history.
     */
    private void loadHistory() {

        historyList =
                dbHelper.getWorkoutHistory(userId);

        adapter = new WeightAdapter(
                this,
                historyList,

                // DELETE callback
                position -> {

                    WorkoutHistory entry =
                            historyList.get(position);

                    dbHelper.deleteWorkoutHistory(
                            entry.getId(),
                            userId
                    );

                    loadHistory();
                },

                // EDIT callback
                position -> {

                    WorkoutHistory entry =
                            historyList.get(position);

                    Intent intent =
                            new Intent(
                                    this,
                                    EditWeightActivity.class
                            );

                    intent.putExtra(
                            "id",
                            entry.getId()
                    );

                    intent.putExtra(
                            "weight",
                            entry.getWeight()
                    );

                    intent.putExtra(
                            "date",
                            entry.getDate()
                    );

                    intent.putExtra(
                            "steps",
                            entry.getSteps()
                    );

                    startActivity(intent);
                }
        );

        recyclerViewHistory.setLayoutManager(
                new LinearLayoutManager(this)
        );

        recyclerViewHistory.setAdapter(
                adapter
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }
}