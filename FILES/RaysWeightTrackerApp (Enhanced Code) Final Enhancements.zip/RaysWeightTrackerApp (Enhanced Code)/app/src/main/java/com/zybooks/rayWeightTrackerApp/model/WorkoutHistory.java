package com.zybooks.rayWeightTrackerApp.model;

public class WorkoutHistory {
    private long id;
    private long userId;
    private String date;
    private float weight;
    private int steps;

    public WorkoutHistory(long id, long userId, String date, float weight, int steps) {
        this.id = id;
        this.userId = userId;
        this.date = date;
        this.weight = weight;
        this.steps = steps;
    }

    public long getId() { return id; }
    public long getUserId() { return userId; }
    public String getDate() { return date; }
    public float getWeight() { return weight; }
    public int getSteps() { return steps; }
}
