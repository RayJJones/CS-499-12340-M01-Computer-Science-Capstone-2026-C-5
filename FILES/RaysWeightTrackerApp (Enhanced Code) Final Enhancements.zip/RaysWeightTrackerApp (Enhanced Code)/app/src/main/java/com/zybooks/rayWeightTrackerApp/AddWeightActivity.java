package com.zybooks.rayWeightTrackerApp;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.rayWeightTrackerApp.data.AppDatabaseHelper;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Activity for adding a weight and daily step entry.
 *
 * The activity allows the logged-in user to:
 * - Enter a weight
 * - Enter a daily step count
 * - Enter a date manually
 * - Select a date using the calendar
 * - Save the information in WorkoutHistory
 */
public class AddWeightActivity extends AppCompatActivity {

    private EditText etWeightInput;
    private EditText etStepsInput;
    private EditText etDateInput;
    private TextView tvWelcomeUser;

    private AppDatabaseHelper dbHelper;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        tvWelcomeUser =
                findViewById(R.id.tvWelcomeUser);

        etWeightInput =
                findViewById(R.id.etWeightInput);

        etStepsInput =
                findViewById(R.id.etStepsInput);

        etDateInput =
                findViewById(R.id.etDateInput);

        ImageView btnCalendar =
                findViewById(R.id.btnCalendar);

        Button btnSaveWeight =
                findViewById(R.id.btnSaveWeight);

        Button btnBackHome =
                findViewById(R.id.btnBackHome);

        dbHelper =
                new AppDatabaseHelper(this);

        SharedPreferences session =
                getSharedPreferences(
                        "userSession",
                        MODE_PRIVATE
                );

        userId =
                session.getLong(
                        "userId",
                        1L
                );

        String username =
                dbHelper.getUsername(userId);

        tvWelcomeUser.setText(
                getString(
                        R.string.welcome_user_format,
                        username
                )
        );

        btnCalendar.setOnClickListener(
                view -> openDatePicker()
        );

        btnSaveWeight.setOnClickListener(
                view -> saveWeight()
        );

        btnBackHome.setOnClickListener(
                view -> finish()
        );
    }

    /**
     * Opens the calendar picker and formats the selected
     * date as MM/DD/YYYY.
     */
    private void openDatePicker() {

        Calendar calendar =
                Calendar.getInstance();

        DatePickerDialog dialog =
                new DatePickerDialog(
                        this,
                        (
                                DatePicker view,
                                int year,
                                int month,
                                int day
                        ) -> {

                            String selectedDate =
                                    String.format(
                                            Locale.US,
                                            "%02d/%02d/%04d",
                                            month + 1,
                                            day,
                                            year
                                    );

                            etDateInput.setText(
                                    selectedDate
                            );

                            etDateInput.setError(null);
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                );

        dialog.show();
    }

    /**
     * Confirms that the date uses the exact MM/DD/YYYY format
     * and represents a valid calendar date.
     */
    private boolean isValidDate(String dateText) {

        if (!dateText.matches(
                "\\d{2}/\\d{2}/\\d{4}"
        )) {
            return false;
        }

        SimpleDateFormat dateFormat =
                new SimpleDateFormat(
                        "MM/dd/yyyy",
                        Locale.US
                );

        dateFormat.setLenient(false);

        ParsePosition position =
                new ParsePosition(0);

        return dateFormat.parse(
                dateText,
                position
        ) != null
                && position.getIndex()
                == dateText.length();
    }

    /**
     * Validates and saves the weight, steps, and date.
     */
    private void saveWeight() {

        String weightText =
                etWeightInput
                        .getText()
                        .toString()
                        .trim();

        String stepsText =
                etStepsInput
                        .getText()
                        .toString()
                        .trim();

        String dateText =
                etDateInput
                        .getText()
                        .toString()
                        .trim();

        /*
         * Validate weight.
         */
        if (weightText.isEmpty()) {

            etWeightInput.setError(
                    getString(
                            R.string.error_weight_required
                    )
            );

            etWeightInput.requestFocus();
            return;
        }

        float weight;

        try {

            weight =
                    Float.parseFloat(weightText);

        } catch (NumberFormatException exception) {

            etWeightInput.setError(
                    getString(
                            R.string.error_invalid_weight
                    )
            );

            etWeightInput.requestFocus();
            return;
        }

        if (weight <= 0) {

            etWeightInput.setError(
                    getString(
                            R.string.error_weight_positive
                    )
            );

            etWeightInput.requestFocus();
            return;
        }

        /*
         * Validate steps.
         */
        if (stepsText.isEmpty()) {

            etStepsInput.setError(
                    getString(
                            R.string.error_steps_required
                    )
            );

            etStepsInput.requestFocus();
            return;
        }

        int steps;

        try {

            steps =
                    Integer.parseInt(stepsText);

        } catch (NumberFormatException exception) {

            etStepsInput.setError(
                    getString(
                            R.string.error_invalid_steps
                    )
            );

            etStepsInput.requestFocus();
            return;
        }

        if (steps < 0) {

            etStepsInput.setError(
                    getString(
                            R.string.error_steps_negative
                    )
            );

            etStepsInput.requestFocus();
            return;
        }

        /*
         * Validate date.
         */
        if (dateText.isEmpty()) {

            etDateInput.setError(
                    getString(
                            R.string.error_date_required
                    )
            );

            etDateInput.requestFocus();
            return;
        }

        if (!isValidDate(dateText)) {

            etDateInput.setError(
                    getString(
                            R.string.error_date_format
                    )
            );

            etDateInput.requestFocus();
            return;
        }

        boolean success =
                dbHelper.addWorkoutHistory(
                        userId,
                        dateText,
                        weight,
                        steps
                );

        if (success) {

            Toast.makeText(
                    this,
                    R.string.weight_and_steps_saved,
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    R.string.weight_save_failed,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}