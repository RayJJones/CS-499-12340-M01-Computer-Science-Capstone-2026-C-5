package com.zybooks.rayWeightTrackerApp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

/**
 * Activity for adding a new weight entry.
 * Allows user to enter weight, select a date, and save to database.
 */
public class AddWeightActivity extends AppCompatActivity {

    private EditText etWeightInput;
    private EditText etDateInput;
    private ImageView btnCalendar;
    private Button btnSaveWeight;

    private WeightDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Initialize UI components
        etWeightInput = findViewById(R.id.etWeightInput);
        etDateInput = findViewById(R.id.etDateInput);
        btnCalendar = findViewById(R.id.btnCalendar);
        btnSaveWeight = findViewById(R.id.btnSaveWeight);

        // Navigate back to dashboard
        Button btnBackHome = findViewById(R.id.btnBackHome);
        btnBackHome.setOnClickListener(v ->
                startActivity(new Intent(this, DashboardActivity.class)));

        // Initialize database helper
        dbHelper = new WeightDatabaseHelper(this);

        // Open date picker dialog
        btnCalendar.setOnClickListener(v -> openDatePicker());

        // Save weight entry
        btnSaveWeight.setOnClickListener(v -> saveWeight());
    }

    /**
     * Opens a date picker dialog and sets the selected date.
     */
    private void openDatePicker() {
        Calendar calendar = Calendar.getInstance();

        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (DatePicker view, int year, int month, int day) -> {
                    String date = (month + 1) + "/" + day + "/" + year;
                    etDateInput.setText(date);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        dialog.show();
    }

    /**
     * Validates input and saves weight entry to database.
     */
    private void saveWeight() {
        String weightStr = etWeightInput.getText().toString().trim();
        String date = etDateInput.getText().toString().trim();

        if (weightStr.isEmpty() || date.isEmpty()) {
            Toast.makeText(this, "Please enter weight and date", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight = Double.parseDouble(weightStr);

        boolean success = dbHelper.addWeight(date, weight);

        if (success) {
            Toast.makeText(this, "Weight saved!", Toast.LENGTH_SHORT).show();
            finish(); // Return to Dashboard
        } else {
            Toast.makeText(this, "Error saving weight", Toast.LENGTH_SHORT).show();
        }
    }
}
