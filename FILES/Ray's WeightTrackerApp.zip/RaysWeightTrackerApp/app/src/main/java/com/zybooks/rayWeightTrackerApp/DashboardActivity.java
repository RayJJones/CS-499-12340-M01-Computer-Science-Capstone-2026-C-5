package com.zybooks.rayWeightTrackerApp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Main dashboard showing progress toward goal weight
 * and navigation to other features.
 */
public class DashboardActivity extends AppCompatActivity {

    private ProgressBar progressGoal;
    private TextView tvGoalStatus;
    private TextView tvCongrats;

    private GoalDatabaseHelper goalDb;
    private WeightDatabaseHelper weightDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize UI
        progressGoal = findViewById(R.id.progressGoal);
        tvGoalStatus = findViewById(R.id.tvGoalStatus);
        tvCongrats = findViewById(R.id.tvCongrats);

        // Initialize database helpers
        goalDb = new GoalDatabaseHelper(this);
        weightDb = new WeightDatabaseHelper(this);

        updateProgress();

        // Navigation buttons
        findViewById(R.id.btnAddNewWeight).setOnClickListener(v ->
                startActivity(new Intent(this, AddWeightActivity.class)));

        findViewById(R.id.btnSetGoal).setOnClickListener(v ->
                startActivity(new Intent(this, GoalWeightActivity.class)));

        findViewById(R.id.btnViewHistory).setOnClickListener(v ->
                startActivity(new Intent(this, WeightHistoryActivity.class)));

        findViewById(R.id.btnSettings).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
    }

    /**
     * Updates progress bar and goal status text.
     */
    private void updateProgress() {
        double goal = goalDb.getGoalWeight();
        double latest = weightDb.getLatestWeight();

        if (goal == 0) {
            tvGoalStatus.setText("No goal set yet");
            progressGoal.setProgress(0);
            return;
        }

        if (latest == 0) {
            tvGoalStatus.setText("Add your first weight to begin tracking");
            progressGoal.setProgress(0);
            return;
        }

        double progress = (latest / goal) * 100;
        progressGoal.setProgress((int) progress);

        tvGoalStatus.setText("Current: " + latest + " lbs / Goal: " + goal + " lbs");

        tvCongrats.setVisibility(latest <= goal ? TextView.VISIBLE : TextView.GONE);
    }
}
