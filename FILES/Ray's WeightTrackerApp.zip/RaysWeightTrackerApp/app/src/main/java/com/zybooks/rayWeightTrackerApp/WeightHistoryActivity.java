package com.zybooks.rayWeightTrackerApp;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Displays a list of all saved weight entries.
 * Allows users to edit or delete individual entries.
 */
public class WeightHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewHistory;
    private WeightAdapter adapter;
    private ArrayList<WeightEntry> weightList;

    private WeightDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_history);

        // Initialize UI components
        recyclerViewHistory = findViewById(R.id.recyclerViewHistory);

        // Back to dashboard
        Button btnBackHome = findViewById(R.id.btnBackHome);
        btnBackHome.setOnClickListener(v ->
                startActivity(new Intent(this, DashboardActivity.class)));

        // Initialize database helper
        dbHelper = new WeightDatabaseHelper(this);

        // Load weight history into RecyclerView
        loadHistory();
    }

    /**
     * Loads all weight entries from the database and updates the RecyclerView.
     */
    private void loadHistory() {
        weightList = dbHelper.getAllWeights();

        adapter = new WeightAdapter(
                this,
                weightList,

                // DELETE callback
                position -> {
                    WeightEntry entry = weightList.get(position);
                    dbHelper.deleteWeight(entry.getId());
                    loadHistory(); // Refresh list after deletion
                },

                // EDIT callback
                position -> {
                    WeightEntry entry = weightList.get(position);

                    Intent intent = new Intent(this, EditWeightActivity.class);
                    intent.putExtra("id", entry.getId());
                    intent.putExtra("weight", entry.getWeight());
                    intent.putExtra("date", entry.getDate());
                    startActivity(intent);
                }
        );

        recyclerViewHistory.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewHistory.setAdapter(adapter);
    }

    /**
     * Refreshes the list when returning from EditWeightActivity.
     */
    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }
}
