package com.zybooks.rayWeightTrackerApp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity for updating username and password.
 */
public class SettingsActivity extends AppCompatActivity {

    private EditText etNewUsername;
    private EditText etNewPassword;
    private Button btnSaveSettings;

    private UserDatabaseHelper userDb;
    private String currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize UI components
        etNewUsername = findViewById(R.id.etNewUsername);
        etNewPassword = findViewById(R.id.etNewPassword);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);

        // Initialize database helper
        userDb = new UserDatabaseHelper(this);

        // Retrieve logged-in username
        currentUser = getIntent().getStringExtra("username");

        // Navigate back to dashboard
        Button btnBackHome = findViewById(R.id.btnBackHome);
        btnBackHome.setOnClickListener(v ->
                startActivity(new Intent(this, DashboardActivity.class)));

        // Save updated settings
        btnSaveSettings.setOnClickListener(v -> saveSettings());
    }

    /**
     * Validates and updates user account information.
     */
    private void saveSettings() {
        String newUsername = etNewUsername.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();

        if (newUsername.isEmpty() || newPassword.isEmpty()) {
            Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = userDb.updateUser(currentUser, newUsername, newPassword);

        if (success) {
            Toast.makeText(this, "Settings updated!", Toast.LENGTH_SHORT).show();
            finish(); // Return to Dashboard
        } else {
            Toast.makeText(this, "Error updating settings", Toast.LENGTH_SHORT).show();
        }
    }
}
