package com.zybooks.rayWeightTrackerApp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity for setting or updating the user's goal weight.
 */
public class GoalWeightActivity extends AppCompatActivity {

    private EditText etGoalWeight;
    private Button btnSaveGoal;

    private GoalDatabaseHelper goalDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        // Initialize UI components
        etGoalWeight = findViewById(R.id.etGoalWeight);
        btnSaveGoal = findViewById(R.id.btnSaveGoal);

        // Navigate back to dashboard
        Button btnBackHome = findViewById(R.id.btnBackHome);
        btnBackHome.setOnClickListener(v ->
                startActivity(new Intent(this, DashboardActivity.class)));

        // Initialize database helper
        goalDb = new GoalDatabaseHelper(this);

        // Save goal weight
        btnSaveGoal.setOnClickListener(v -> saveGoal());
    }

    /**
     * Validates input and saves the user's goal weight.
     */
    private void saveGoal() {
        String goalStr = etGoalWeight.getText().toString().trim();

        if (goalStr.isEmpty()) {
            Toast.makeText(this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double goal = Double.parseDouble(goalStr);

        boolean success = goalDb.setGoalWeight(goal);

        if (success) {
            Toast.makeText(this, "Goal weight saved!", Toast.LENGTH_SHORT).show();
            finish(); // Return to Dashboard
        } else {
            Toast.makeText(this, "Error saving goal", Toast.LENGTH_SHORT).show();
        }
    }
}
