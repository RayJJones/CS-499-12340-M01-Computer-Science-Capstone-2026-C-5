package com.zybooks.rayWeightTrackerApp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity for editing an existing weight entry.
 * Receives entry data from WeightHistoryActivity and updates the database.
 */
public class EditWeightActivity extends AppCompatActivity {

    private EditText etEditWeight;
    private EditText etEditDate;
    private Button btnSaveEdit;
    private Button btnCancelEdit;

    private WeightDatabaseHelper dbHelper;
    private long entryId;   // Use long to match SQLite row IDs

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight);

        // Initialize UI components
        etEditWeight = findViewById(R.id.etEditWeight);
        etEditDate = findViewById(R.id.etEditDate);
        btnSaveEdit = findViewById(R.id.btnSaveEdit);
        btnCancelEdit = findViewById(R.id.btnCancelEdit);

        // Initialize database helper
        dbHelper = new WeightDatabaseHelper(this);

        // Retrieve entry data passed from WeightHistoryActivity
        Intent intent = getIntent();
        entryId = intent.getLongExtra("id", -1);
        double weight = intent.getDoubleExtra("weight", 0);
        String date = intent.getStringExtra("date");

        // Pre-fill fields with existing values
        etEditWeight.setText(String.valueOf(weight));
        etEditDate.setText(date);

        // Save updated values
        btnSaveEdit.setOnClickListener(v -> saveUpdatedWeight());

        // Cancel and return to previous screen
        btnCancelEdit.setOnClickListener(v -> finish());
    }

    /**
     * Validates input and updates the weight entry in the database.
     */
    private void saveUpdatedWeight() {
        String newDate = etEditDate.getText().toString().trim();
        String newWeightStr = etEditWeight.getText().toString().trim();

        // Ensure both fields are filled out
        if (newDate.isEmpty() || newWeightStr.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double newWeight = Double.parseDouble(newWeightStr);

        // Update entry in database
        boolean updated = dbHelper.updateWeight(entryId, newWeight, newDate);

        if (updated) {
            Toast.makeText(this, "Weight updated!", Toast.LENGTH_SHORT).show();
            finish(); // Return to WeightHistoryActivity
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }
}
