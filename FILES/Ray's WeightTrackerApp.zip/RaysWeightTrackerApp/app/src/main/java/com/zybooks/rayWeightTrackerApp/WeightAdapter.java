package com.zybooks.rayWeightTrackerApp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final Context context;
    private final ArrayList<WeightEntry> weightList;

    // DELETE callback
    private final OnDeleteClickListener deleteListener;

    // EDIT callback
    private final OnEditClickListener editListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    public interface OnEditClickListener {
        void onEditClick(int position);
    }

    // UPDATED constructor to include editListener
    public WeightAdapter(Context context,
                         ArrayList<WeightEntry> weightList,
                         OnDeleteClickListener deleteListener,
                         OnEditClickListener editListener) {

        this.context = context;
        this.weightList = weightList;
        this.deleteListener = deleteListener;
        this.editListener = editListener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.row_weight, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);

        holder.tvDate.setText(entry.getDate());
        holder.tvWeight.setText(String.valueOf(entry.getWeight()));

        // DELETE button
        holder.btnDelete.setOnClickListener(v ->
                deleteListener.onDeleteClick(position)
        );

        // EDIT button
        holder.btnEdit.setOnClickListener(v ->
                editListener.onEditClick(position)
        );
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {

        TextView tvDate, tvWeight;
        Button btnDelete, btnEdit;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);

            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnEdit = itemView.findViewById(R.id.btnEdit);   // NEW
        }
    }
}

